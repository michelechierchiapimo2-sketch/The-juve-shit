import threading
import time

from chat import chat_loop
from event import event_loop
from save_manager import load_game, save_game
from resources import show_resources

class GameEngine:
    def __init__(self):
        self.state = load_game()
        self.running = True

    def start(self):
        chat_thread = threading.Thread(target=chat_loop, args=(self,))
        event_thread = threading.Thread(target=event_loop, args=(self,))

        chat_thread.start()
        event_thread.start()

        while self.running:
            command = input("\n> ")

            if command == "status":
                show_resources(self.state)

            elif command == "exit":
                self.running = False
                save_game(self.state)
                print("Gioco salvato. Uscita.")

            time.sleep(0.2)

