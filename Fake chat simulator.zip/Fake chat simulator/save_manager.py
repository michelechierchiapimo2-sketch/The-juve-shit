import json

FILE = "data/game_state.json"

def load_game():
    with open(FILE, "r") as f:
        return json.load(f)

def save_game(state):
    with open(FILE, "w") as f:
        json.dump(state, f, indent=4)
