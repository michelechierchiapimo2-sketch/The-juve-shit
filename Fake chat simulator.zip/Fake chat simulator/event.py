import time
import random

def event_loop(game):
    while game.running:
        time.sleep(5)

        event = random.choice(["spam", "bonus", "nothing"])

        if event == "spam":
            game.state["reputation"] -= 5
            print("\n⚠️ Spam rilevato! Reputazione -5")

        if event == "bonus":
            game.state["money"] += 100
            print("\n💰 Bonus ricevuto! +100 soldi")

