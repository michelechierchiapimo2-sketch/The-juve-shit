def show_resources(state):
    print("\n📊 STATO GIOCO")
    print("Soldi:", state["money"])
    print("Reputazione:", state["reputation"])
    print("Tempo:", state["time"])
    print("Messaggi:", len(state["messages"]))