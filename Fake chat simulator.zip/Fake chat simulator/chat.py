import time
import random

USERS = ["Alice", "Bob", "Carla", "Davide"]

def chat_loop(game):
    while game.running:
        time.sleep(3)

        user = random.choice(USERS)
        message = random.choice([
            "Ciao!",
            "Come va?",
            "Rispondi pls",
            "Messaggio casuale"
        ])

        game.state["messages"].append({
            "user": user,
            "text": message
        })

        game.state["time"] += 1
        game.state["reputation"] += 1

        print(f"\n💬 {user}: {message}")


