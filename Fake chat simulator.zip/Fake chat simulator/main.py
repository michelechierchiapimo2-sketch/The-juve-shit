from engine import GameEngine

game = GameEngine()
game.start()

